if (GlobalVars.getBoolean("ToggleScript") && GlobalVars.getBoolean("Reconnect")) {
    Client.connect("us.hypixel.net")
}