KeyBind.key(57, true);
Client.waitTick(1);
KeyBind.key(57, false);
