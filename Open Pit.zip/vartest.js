Chat.log("Title: " + World.getScoreboards().getCurrentScoreboard().getName())
Chat.log("Players: " + World.getPlayers())
