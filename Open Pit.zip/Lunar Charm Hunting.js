let str = event.text.toString();
const POSITIONCOMMON_VEC3D = Java.type("xyz.wagyourtail.jsmacros.client.api.sharedclasses.PositionCommon$Vec3D")
const player = Player.getPlayer()
var dropX = 0
var dropY = 0
var dropZ = 0
var totalEntity = 0
var block = {x: dropX, y:dropY, z:dropZ}
const vec = new POSITIONCOMMON_VEC3D(player.getX(), player.getY() +player.getEyeHeight(), player.getZ(), block.x, block.y, block.z)
const goalYaw = vec.getYaw()
const TIME = Math.floor(Math.random() * 150 + 600)
const STEPS = TIME / TIME_INTERVAL

function look(v1, v2, v3) {
    var players = World.getPlayers().toArray()
    var thisTime = Time.time()
    let yawDifference = goalYaw - player.getYaw();
    if (yawDifference <= -180) yawDiffernce = 360 + yawDifference;
    else if (yawDifference >= 180) yawDifference = 360 - yawDifference;
    for(let i = 0; i < STEPS; i++) {
        player.lookAt(player.getYaw() + yawDifference / STEPS, player.getPitch())
        Time.sleep(TIME_INTERVAL())
    }
}

if (str.includes("LIGHTER", 0)) {
    var items = World.getEntities().toArray()
    for (let i = 0; i < items.length; i++) {
        var itemName = items[i].getName().toString()
        //Chat.log(itemName)
        if (itemName.includes("Lunar Charm", 0)) {
            dropX = Math.floor(items[i].getX())
            dropY = Math.floor(items[i].getY())
            dropZ = Math.floor(items[i].getZ())
            totalEntity++
        }
        else {
            totalEntity++
        }
    }
    if (dropX !== 0 || dropY !== 0 || dropZ !== 0) {
        Chat.log("Found Lunar Charm: " + dropX + " " + dropY + " " + dropZ)
        Chat.log("Looking towards it...")
        Look
    }
    else {
        Chat.log("<Err!>")
    }
}

function TIME_INTERVAL() {
    return Math.floor(Math.random() * 7)
}
