KeyBind.key(42, true)
Time.sleep(Math.floor(Math.random() * 1500 + 800))
KeyBind.key(42, false)
